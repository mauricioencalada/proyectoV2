export declare class NgxSpinnerModule {
}
