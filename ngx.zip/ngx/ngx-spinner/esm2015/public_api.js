/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/*
 * Public API Surface of ngx-spinner
 */
export { NgxSpinnerService } from './lib/ngx-spinner.service';
export { NgxSpinnerComponent } from './lib/ngx-spinner.component';
export { NgxSpinnerModule } from './lib/ngx-spinner.module';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25neC1zcGlubmVyLyIsInNvdXJjZXMiOlsicHVibGljX2FwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBSUEsa0NBQWMsMkJBQTJCLENBQUM7QUFDMUMsb0NBQWMsNkJBQTZCLENBQUM7QUFDNUMsaUNBQWMsMEJBQTBCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogUHVibGljIEFQSSBTdXJmYWNlIG9mIG5neC1zcGlubmVyXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvbmd4LXNwaW5uZXIuc2VydmljZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9uZ3gtc3Bpbm5lci5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbmd4LXNwaW5uZXIubW9kdWxlJztcbiJdfQ==